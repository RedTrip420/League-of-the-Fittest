
import React, { useState } from 'react';

export default function LolAutoWorkout() {
  const [summonerName, setSummonerName] = useState('');
  const [server, setServer] = useState('euw1'); // Standard ist EUW
  const [apiKey, setApiKey] = useState('');
  const [workout, setWorkout] = useState('');

  const fetchSummonerData = async () => {
    try {
      // Baue die URL zur Riot API
      const url = `https://${server}.api.riotgames.com/lol/summoner/v4/summoners/by-name/${summonerName}?api_key=${apiKey}`;
      console.log("API URL:", url); // Loggt die vollständige URL zur API

      const response = await fetch(url);

      // Loggt den Statuscode der API-Antwort
      console.log("API Antwort-Status:", response.status);

      // Überprüfen, ob die Antwort OK ist
      if (!response.ok) {
        // Wenn der Status nicht OK ist, werfen wir einen Fehler
        throw new Error(`Fehler: ${response.statusText}`);
      }

      // Holen der JSON-Daten
      const data = await response.json();
      console.log("Summoner-Daten:", data); // Loggt die erhaltenen Daten

      setWorkout('Workout basierend auf deinen Game-Daten'); // Hier kannst du die Logik für das Workout einfügen
    } catch (error) {
      console.error("Fehler beim Abrufen der Daten:", error);
      alert('Fehler beim Abrufen der Daten: ' + error.message); // Zeigt den Fehler als Alert an
    }
  };

  return (
    <div>
      <h1>League of Legends Workout Tracker</h1>
      <input
        type="text"
        placeholder="Summoner Name"
        value={summonerName}
        onChange={(e) => setSummonerName(e.target.value)}
      />
      <select value={server} onChange={(e) => setServer(e.target.value)}>
        <option value="euw1">EU West</option>
        <option value="na1">NA</option>
        <option value="kr">KR</option>
        {/* Weitere Server kannst du hier hinzufügen */}
      </select>
      <input
        type="text"
        placeholder="API Key"
        value={apiKey}
        onChange={(e) => setApiKey(e.target.value)}
      />
      <button onClick={fetchSummonerData}>Fetch Summoner Data</button>

      <div>
        <h2>Workout</h2>
        <p>{workout}</p>
      </div>
    </div>
  );
}
