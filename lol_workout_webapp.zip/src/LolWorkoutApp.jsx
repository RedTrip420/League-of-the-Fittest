import { useState } from "react";
import { motion } from "framer-motion";

export default function LolWorkoutApp() {
  const [stats, setStats] = useState({
    kills: 0,
    deaths: 0,
    assists: 0,
    objectives: 0,
    firstBlood: false,
    penta: false,
    afk: false,
    win: true,
  });

  const [notes, setNotes] = useState("");
  const [finished, setFinished] = useState(false);

  const calculateWorkout = () => {
    const total = {
      pushUps: stats.kills * 5,
      burpees: stats.deaths * 5 + (stats.penta ? 20 : 0),
      sitUps: stats.assists * 5 + (stats.afk ? 50 : 0),
      jumpingJacks: stats.objectives * 10,
      climbers: stats.firstBlood ? 10 : 0,
      plank: stats.win ? 1 : 2,
      squats: stats.win ? 20 : 40,
    };
    return total;
  };

  const total = calculateWorkout();

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a0f1a] to-[#1a2238] text-white p-4">
      <motion.h1 className="text-3xl font-bold text-center mb-4" initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
        League of Legends Workout Scorecard
      </motion.h1>

      <div className="max-w-xl mx-auto bg-[#111827] border border-[#374151] shadow-xl rounded-2xl p-6 space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <input type="number" placeholder="Kills" onChange={(e) => setStats({ ...stats, kills: parseInt(e.target.value) || 0 })} />
          <input type="number" placeholder="Deaths" onChange={(e) => setStats({ ...stats, deaths: parseInt(e.target.value) || 0 })} />
          <input type="number" placeholder="Assists" onChange={(e) => setStats({ ...stats, assists: parseInt(e.target.value) || 0 })} />
          <input type="number" placeholder="Objectives" onChange={(e) => setStats({ ...stats, objectives: parseInt(e.target.value) || 0 })} />
        </div>

        <label><input type="checkbox" checked={stats.firstBlood} onChange={(e) => setStats({ ...stats, firstBlood: e.target.checked })} /> First Blood</label>
        <label><input type="checkbox" checked={stats.penta} onChange={(e) => setStats({ ...stats, penta: e.target.checked })} /> Penta Kill</label>
        <label><input type="checkbox" checked={stats.afk} onChange={(e) => setStats({ ...stats, afk: e.target.checked })} /> AFK?</label>
        <label><input type="checkbox" checked={stats.win} onChange={(e) => setStats({ ...stats, win: e.target.checked })} /> Win?</label>

        <textarea placeholder="Notizen..." className="w-full bg-[#1f2937] text-white p-2 rounded" onChange={(e) => setNotes(e.target.value)} />

        <div className="bg-[#1f2937] p-4 rounded-xl space-y-2">
          <h2 className="font-semibold text-lg text-yellow-400">Dein Workout:</h2>
          <p>🔹 Push-Ups: {total.pushUps}</p>
          <p>🔹 Burpees: {total.burpees}</p>
          <p>🔹 Sit-Ups: {total.sitUps}</p>
          <p>🔹 Jumping Jacks: {total.jumpingJacks}</p>
          <p>🔹 Mountain Climbers: {total.climbers}</p>
          <p>🔹 Plank: {total.plank} Minute(n)</p>
          <p>🔹 Squats: {total.squats}</p>
        </div>

        <label><input type="checkbox" checked={finished} onChange={(e) => setFinished(e.target.checked)} /> Workout erledigt?</label>
      </div>
    </div>
  );
}
