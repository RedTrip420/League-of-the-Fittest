import React from 'react'
import ReactDOM from 'react-dom/client'
import './index.css'
import LolWorkoutApp from './LolWorkoutApp'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <LolWorkoutApp />
  </React.StrictMode>,
)
